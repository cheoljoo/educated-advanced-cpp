#include <iostream>
#include <type_traits> 

struct PACKET
{
	char cmd;
	int  data;
};

template<typename T> void object_set_zero(T* p)
{
	memset(p, 0, sizeof(T)); // ������ �ڵ� �ϱ�� ?
}

int main()
{
	std::cout << sizeof(PACKET) << std::endl; // ?
}