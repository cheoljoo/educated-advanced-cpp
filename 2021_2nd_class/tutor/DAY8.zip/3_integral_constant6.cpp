﻿#include <iostream>



int main()
{

}
