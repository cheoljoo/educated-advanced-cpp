﻿#include <iostream>
#include <string>
#include <vector>

// 106 page

class Object {};

class Test
{
	Object data;
public:
	// setter 만들기 
	// call by value => 복사본에 의한 오버헤드가 있다.
	// void setData(Object o) { data = o; }

	// C++98 시절의 최고의 코드!! - 하지만 C++11에서는 단점이 있다.
//	void setData(const Object& o) { data = o; } // 항상 복사 
//	void setData(const Object& o) { data = std::move(o); } // 항상 복사(o가 상수객체이므로)


	// C++11 이후에 setter를 만드는 방법
	// 1. 2개의 함수 제공
	// void setData(const Object& o) { data = o; }
	// void setData(Object&& o)      { data = std::move(o); }

	// 방법 2. C++11 이후에는 call by value 가 아주 나쁜 것은 아니다.
	// MOVE생성자가 충분 빠른 타입이라면 call by value도 나쁘지 않다
	// boost::asio 등의 라이브러리가 call(pass) by value 
//	void setData(Object obj) { data = std::move(obj); }
//	void setData(Object obj) { data = obj; } // C++98시절은 move가 없었습니다.
											// 이렇게 하면 복사1회의 오버헤드가 됩니다.

	// 방법 3. "T&&" 를 사용하면 (1)번의 2개 함수를 자동으로 만들수 있다.
	template<typename T> void setData(T&& o)
	{
		// 다음중 맞는 것은 ?
		//data = o;			 // 무조건 복사
		//data = std::move(o); // 무조건 이동
		data = std::forward<T>(o);  // lvalue를 받으면 static_cast<Object&> 로 캐스팅- 복사
									// rvalue를 받으면 static_cast<Object&&>로 캐스팅- 이동
	}
};
int main()
{
	Test test;
	Object o1;

	test.setData(o1); // o1의 자원을 복사해 가라. o1 자체는 계속 사용할 것이다
					  // 복사 1회 호출
					  // 복사 1회, MOVE 1회

	test.setData(std::move(o1)); // o1의 자원을 move로 가져가라. o1은 더이상 자원 없음.
					 // move 1회 호출.
					 // MOVE 2회
}








