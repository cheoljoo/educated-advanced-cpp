﻿#include <iostream>
#include <string>


template<typename T, typename U> struct PAIR
{
	T first;
	U second;

	// C++98 시절의 생성자 모양
	// PAIR(const T& a, const U& b) : first(a), second(b) {}

	// C++11 부터는 move를 지원하도록 생성자를 만드는 것이 좋습니다.
	// 인자가 2개인 생성자 => 4개의 생성자 필요
	//        3개          => 8개의 생성자 필요
	//PAIR(const T& a, const U& b) : first(a), second(b) {}
	//PAIR(T&& a, U&& b) : first(std::move(a)), second(std::move(b)) {}
	//PAIR(T&& a, const U& b) : first(std::move(a)), second(b) {}
	//PAIR(const T& a, U&& b) : first(a), second(std::move(b)) {}

	// 결론
	// 인자가 한개인 setter 나 생성자는 2개의 함수를 제공하면 된다.
	// 인자가 2개 이상인 setter 나 생성자는 "forwarding" 를 사용하는 것이 좋다.

	template<typename A, typename B> 
	PAIR(A&& a, B&& b) : first(std::forward<A>(a)), second(std::forward<B>(b)) {}
};

int main()
{
	std::string s1 = "ABC";
	std::string s2 = "EFGH";
	PAIR<std::string, std::string> p1(s1, s2);
	PAIR<std::string, std::string> p2(std::move(s1), s2);

	std::pair<int, int> p(3, 4);
}

// 여기 까지가 move 이야기..
// 아래 코드에서 o1의 자원을 o2로 이동하려고 합니다. __A__에 들어갈 것은 ?

// Object o2 = __A__(o1);

// 1. std::forward()
// 2. std::move()
// 3. std::copy()
// 4. std::send()

// 채팅창 질문에 대한 답변입니다.
constexpr std::pair<int, int> p(3, 4); // 이순간 생성자 호출이 컴파일 시간에 !!
int arr[p.first]; // ok !! 즉  위 p의 생성자 호출이 컴파일 시간에 이루어 집니다.

// 생성자가 constexpr 이면.. 생성자 호출을 컴파일 시간에 할수 있습니다.
// 따라서 위코드가 문제 없습니다
