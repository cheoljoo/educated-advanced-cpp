﻿// C++98 의 초기화 리스트에 대한 설명
#include <string>
#include <iostream>

class People
{
	std::string name;
	int age;
public:
	People(std::string n, int a) : name(n), age(a)
	{
		name = n;
		age = a;
	}
};
int main()
{
	People p("kim", 10);

	std::string s1("kim");
	std::string s2;
	s2 = "kim";

	int n1 = 10;
	int n2;
	n2 = 10;
}
