﻿// 초기화 리스트가 반드시 필요한 경우가 있다.
class Point
{
	int x, y;
public:
	Point(int a, int b) : x(a), y(b) {}
};

class Rect
{
	Point from;
	Point to;
public:
	Rect() 
	{
	}
};
int main()
{
	Rect r;
}