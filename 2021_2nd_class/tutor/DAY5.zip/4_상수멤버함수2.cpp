﻿class Rect
{
	int x, y, w, h;
public:
	int getArea()  { return w * h; }
};

void foo(Rect r)
{
	int n = r.getArea(); 
}
int main()
{
	Rect r; // 초기화 했다고 가정..
	int n = r.getArea();
	foo(r);
}