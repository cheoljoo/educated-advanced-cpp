﻿// 자동 생성 규칙.
#include <iostream>
#include <string>

class Object
{
public:
	std::string name;

	Object() : name("kim") {}
};
int main()
{
	Object o1;
	Object o2 = o1;
	o2 = o1;
	std::cout << o1.name << std::endl;

	Object o3 = std::move(o1);
	o3 = std::move(o2);

	std::cout << o1.name << std::endl;
}