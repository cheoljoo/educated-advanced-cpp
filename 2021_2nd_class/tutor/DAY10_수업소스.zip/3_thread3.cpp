﻿#include <iostream>
#include <thread>
#include <mutex>

std::mutex m;
int shared_data = 10;

// 동기화 객체 사용시 "예외"가 발생하면 dead lock 의 가능성이있습니다.
// lock_guard 를 사용하세요

/*
void foo()
{
	m.lock();
	
	// 공유 자원 사용	
	shared_data = 200;

	m.unlock();
}
*/
void foo()
{
	// 핵심 : 예외 발생시.. 지역변수는 안전하게 파괴 됩니다.
	std::lock_guard<std::mutex> lg(m); // lock_guard의 생성자에서 m.lock()
								       //              소멸자에서 m.unlock()

	// 공유 자원 사용	
	shared_data = 200;
}


int main()
{
	std::thread t1(&foo);
	std::thread t2(&foo);

	t1.join();
	t2.join();
}

