﻿
int main()
{
	int(*f)(int, int) = [](int a, int b) { return a + b; }; 
}








