#include <iostream>
#include <string>
#include <string_view> // C++17

void* operator new(std::size_t sz)
{
//	std::cout << "new : " << sz << "bytes" << std::endl;
	printf("AA\n");

	return malloc(sz);
}

int main()
{
	std::string s1 = "0123456789012adadasdasdasdasdasdsasda3456789012345670sdsdsd"; // 20��

	std::string_view s2 = "AAAA";

	const char s[] = "AAAAAAAAAAAAAAA";
	std::string_view s3 = s; //


	printf("%p, %p\n", s, s3.data());

	std::string s;
}

template<typename T, typename Traits, typename Allocator> 
class basic_string 
{
};
using string = basic_string<char, std::char_traits<char>, std::allocator<char>>;
using wstring = basic_string<wchar_t, std::char_traits<char>, std::allocator<char>>;

/*
// ��� �����
import std.vector; // C++23 
import Hello;

int main()
{
	Hello.foo();
}

// Hello.cxx
export void foo();

void foo()
{

}
*/