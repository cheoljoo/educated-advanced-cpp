﻿#include <iostream>
// C++ 표준 traits 사용법 정리

template<typename T> void foo(T a)
{
	// 1. 타입의 조사

	// 2. 변형 타입 얻기

}

int main()
{
	int n = 0;
	foo(&n);
}
