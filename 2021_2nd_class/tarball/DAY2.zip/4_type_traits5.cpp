﻿// remove_all_pointer
