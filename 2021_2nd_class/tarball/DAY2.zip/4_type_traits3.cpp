﻿// is_array 만들기
