﻿#include "cppmaster.h"

int main()
{
	int n = 10;
	 
	n = 10;		
	n + 5 = 10; 
	n + 2 * 5 = 30;

	++n = 10;	


}
