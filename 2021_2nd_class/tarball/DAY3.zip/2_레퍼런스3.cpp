﻿using LREF = int&; // typedef int& LREF;
using RREF = int&&;

int main()
{
	int n = 10;

	LREF r1 = ?;
	RREF r2 = ?;

}
