﻿int main()
{
	int n = 10;

	int& r1 = n;  
	int& r2 = 10; 	
}
