﻿//move6 복사
