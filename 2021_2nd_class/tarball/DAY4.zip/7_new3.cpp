#include "cppmaster.h"
#include <vector>

class DBConnect {};

int main()
{
	std::vector<int> v(10);

	v.resize(7);
	v.resize(8);


}
