﻿
class istream  
{
public:
	bool fail() { return false; }
};
istream cin;

int main()
{
	int n = 0;
	if (cin) {}
}
