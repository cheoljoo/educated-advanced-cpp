﻿#include <iostream>

int main()
{
	int n;

	std::cin >> n;	// 만약 숫자 말고, 'a' 를 입력하면 어떻게 될까 ?


	std::cout << n << std::endl;
}
