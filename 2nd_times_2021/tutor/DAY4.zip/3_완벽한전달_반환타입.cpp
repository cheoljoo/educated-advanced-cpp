﻿#include <iostream>

int& foo(int& a, double b) { a = 100; return a; }

template<typename F, typename ... T> 
void chronometry(F f, T&& ... args)
{
	f(std::forward<T>(args)...);
}

int main()
{
	int n = 0;

	chronometry(foo, n, 3.4);

	std::cout << n << std::endl;
}
