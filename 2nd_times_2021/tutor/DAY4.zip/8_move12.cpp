#include <iostream>
#include <string>
#include <vector>

// 106 page

class Object {};

class Test
{
	Object data;
public:
	// setter �����
	void setData(Object o) { data = o; }
};

int main()
{
	Test test;
	Object o1;

	test.setData(o1);
	test.setData(std::move(o1));
}








