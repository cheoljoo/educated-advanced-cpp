﻿//9_후위반환 - 73 page

int square(int a)
{
	return a * a;
}


int main()
{
	square(3);
}

