#include "People.h"

// �ڵ� ���� ��Ģ.

class Object
{
	People p; 
public:		  
	Object() : p("kim", 20)
	{
	}
};
int main()
{
	Object o1;
	Object o2 = o1;
	o2 = o1;
	Object o3 = std::move(o1);
	o3 = std::move(o2);
}