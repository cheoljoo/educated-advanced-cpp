﻿// 9_후위반환2 - 73 page 아래 부분
#include <iostream>


int Mul(int a, int b)
{
	return a * b;
}

int main()
{
	std::cout << Mul(3,   4)   << std::endl;
}

