﻿int main()
{
	int n = 10;

	auto a1 = n;
	auto a2 = 10;

	auto& a3 = n;
	auto& a4 = 10;

	auto&& a5 = n;
	auto&& a6 = 10;	
}