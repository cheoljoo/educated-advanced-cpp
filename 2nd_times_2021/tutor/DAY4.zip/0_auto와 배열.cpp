﻿#include <iostream>

int main()
{
	int x[3] = { 1,2,3 };

	auto  a = x[0];// ?

	// 아래 각각의 타입을 예측해 보세요
	auto  a1 = x;	// auto : ?		a1 : ?
	auto& a2 = x;	// auto : ?		a2 : ?
}