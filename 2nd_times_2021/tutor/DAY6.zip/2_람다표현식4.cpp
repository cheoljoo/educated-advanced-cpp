﻿// 람다와 타입
#include <iostream>

// 142 page

int main()
{
	auto f1 = [](int a, int b) { return a + b; };
	auto f2 = [](int a, int b) { return a + b; };

}





