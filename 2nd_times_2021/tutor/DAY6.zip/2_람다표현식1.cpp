﻿#include <iostream>
#include <algorithm>
#include <functional>

bool cmp(int a, int b) { return a < b;  }

int main()
{
	int x[10] = { 1,3,5,7,9,2,4,6,8,10 };

	// sort 하고 싶다면
	// 1. 기본 버전
	std::sort(x, x + 10); 

}





