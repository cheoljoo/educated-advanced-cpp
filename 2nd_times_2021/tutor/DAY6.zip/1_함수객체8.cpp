﻿// 4_상수멤버함수3
#include <iostream>

struct Plus
{
	int operator()(int a, int b) 
	{
		return a + b;
	}
};

// 다양한 이항 함수를 받아서 사용하는 함수.
template<typename T> void foo(const T& p)
{
	int n = p(1, 2); 
}

int main()
{
	Plus p;

	foo(p);
}
