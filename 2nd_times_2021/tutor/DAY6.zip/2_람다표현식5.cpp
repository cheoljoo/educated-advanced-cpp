﻿#include <functional>

int main()
{
	// 람다표현식을 담는 방법 - 143

	auto f1 = [](int a, int b) { return a + b; };
}
