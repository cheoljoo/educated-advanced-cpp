﻿class ClosureType
{
public:
	inline int operator()(int a, int b) { return a + b; }
};
int main()
{
	int v1 = 0, v2 = 0;

	auto f = [](int a, int b) {return a + b; }
}












