﻿#include <iostream>

// auto 와 람다 표현식
int main()
{
	[](int a, int b) { return a + b; };
}

