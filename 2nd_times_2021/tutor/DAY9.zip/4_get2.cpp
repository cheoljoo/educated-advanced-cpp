#include <iostream>
using namespace std;

// Step 3. N���� �����ϴ� tuple
template<typename ... Types> struct xtuple
{
	static constexpr int N = 0;
};

template<typename T, typename ... Types> struct xtuple<T, Types...> : public xtuple<Types...>
{
	T value;
	xtuple() = default;
	xtuple(const T& a, const Types& ... args) : value(a), xtuple<Types...>(args...) {}

	static constexpr int N = xtuple<Types...>::N + 1;
};

int main()
{
	//xtuple<>        
	//xtuple<double>  
	//xtuple<char, double>  
	xtuple<int, char, double> t3(3, 'A', 3.4); 

	cout << t3.value << endl; // ?


}













