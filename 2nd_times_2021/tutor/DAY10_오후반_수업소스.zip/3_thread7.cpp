﻿#include <atomic>

// g++ 3_thread7.cpp  -S  -O2
// cl 3_thread7.cpp   /FAs  /O2
int a = 0;
int b = 0;

// foo, goo 는 다른 스레드가 실행합니다.
//https://preshing.com/20130922/acquire-and-release-fences/
// 2017년 C++ 컨퍼런스 유튜브
// CPPCON

// 책 : modern C++(안드레이 알렉산드레스큐) - 2001
//      Effective-C++ - 3권
//      C++ Template Complete Guide - 2nd

// GOF's 디자인 패턴.


void foo()
{
	a = b + 1;

//	__asm { mfence }

	std::atomic_thread_fence(std::memory_order_seq_cst);


	b = 1;
}

void goo()
{
	if (b == 1)
	{
		// a는 반드시 1일까요 ?
	}
}

int main()
{
}
