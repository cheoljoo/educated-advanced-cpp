﻿#include <iostream>
#include <thread>

// atomic
#include <atomic>

//int x = 0;
std::atomic<int> x = 0; // +, - 등의 연산자가 재정의 되어 있고
						// 내부적으로 fetch_add() 등의 함수를 사용해서 원자연산수행

void foo()
{
//	x = x + 1;
	x.fetch_add(1); // 안전하게 1증가.
}

int main()
{
	std::thread t(&foo);
	t.join();
}
