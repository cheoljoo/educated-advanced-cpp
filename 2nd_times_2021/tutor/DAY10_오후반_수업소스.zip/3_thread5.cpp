﻿#include <iostream>
#include <thread>
#include <future> 
#include <chrono>
using namespace std::chrono;
using namespace std::literals;

int foo()
{
	// 작업후..
	// 그냥 결과만 반환
	return 100;
}

int main()
{
	//int ret1 = foo(); // 주스레드가 실행
	
	std::future<int> ft = std::async(std::launch::async, foo);// 새로운 스레드가 foo 수행


	int ret = ft.get(); // 결과 얻기. 결과가 없으면 대기
	
}






